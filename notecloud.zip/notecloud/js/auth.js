/* ============================================================
   js/auth.js — Authentication
   Register, Login (email + password), Logout
   ============================================================ */
"use strict";

/* ── Register ────────────────────────────────────────────────── */
function doRegister() {
  const name   = document.getElementById("rName").value.trim();
  const email  = document.getElementById("rEmail").value.trim();
  const pass   = document.getElementById("rPass").value;
  const role   = document.getElementById("rRole").value;
  const branch = document.getElementById("rBranch").value;
  const err    = document.getElementById("regErr");

  err.style.display = "none";

  if (!name || !email || !pass) {
    err.textContent   = "Please fill in all fields.";
    err.style.display = "block";
    return;
  }
  if (pass.length < 6) {
    err.textContent   = "Password must be at least 6 characters.";
    err.style.display = "block";
    return;
  }

  auth.createUserWithEmailAndPassword(email, pass)
    .then((userCredential) => {
      // Save extra user info to Firestore
      return db.collection("users").doc(userCredential.user.uid).set({
        name: name,
        email: email.toLowerCase(),
        role: role,
        branch: branch
      });
    })
    .then(() => {
      user = { name, email: email.toLowerCase(), role, branch };
      saveData();
      updateNav();
      if (typeof renderNotes === 'function') renderNotes();
      go("dashboard");
      toast("Welcome to NoteCloud, " + name + "! 🎉");
    })
    .catch((error) => {
      if (error.code === 'auth/email-already-in-use') {
        err.textContent = "This email is already registered. Please login instead.";
      } else {
        err.textContent = error.message;
      }
      err.style.display = "block";
    });
}

/* ── Login ───────────────────────────────────────────────────── */
function doLogin() {
  const name  = document.getElementById("lName").value.trim();
  const email = document.getElementById("lEmail").value.trim();
  const pass  = document.getElementById("lPass").value;
  const err   = document.getElementById("loginErr");

  err.style.display = "none";

  if (!email || !pass) {
    err.textContent   = "Please fill in all fields.";
    err.style.display = "block";
    return;
  }

  auth.signInWithEmailAndPassword(email, pass)
    .then((userCredential) => {
      return db.collection("users").doc(userCredential.user.uid).get();
    })
    .then((doc) => {
      if (doc.exists) {
        const data = doc.data();
        if (name && data.name.toLowerCase() !== name.toLowerCase()) {
          alert("Note: Full name didn't match perfectly, but we found your account by email!");
        }
        user = { name: data.name, email: data.email, role: data.role, branch: data.branch };
        saveData();
        updateNav();
        if (typeof renderNotes === 'function') renderNotes();
        go("dashboard");
        toast("Welcome back, " + user.name + "! 👋");
      } else {
        // Fallback if document missing
        user = { name: "User", email: email, role: "student", branch: "CSE" };
        saveData();
        updateNav();
        go("dashboard");
      }
    })
    .catch((error) => {
      err.textContent = "Incorrect password or email. Please try again.";
      err.style.display = "block";
      document.getElementById("lPass").value = "";
    });
}

/* ── Logout ──────────────────────────────────────────────────── */
function doLogout() {
  auth.signOut().then(() => {
    user = null;
    localStorage.removeItem("nc_user");
    updateNav();
    go("home");
    toast("Logged out successfully.", "info");
  });
}
