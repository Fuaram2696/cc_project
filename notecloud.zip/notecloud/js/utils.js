/* ============================================================
   js/utils.js — Shared Utilities
   Toast, page routing, nav update, type/badge helpers
   ============================================================ */
"use strict";

/* ── Toast notification ──────────────────────────────────────── */
let _toastTimer;

function toast(msg, type = "ok") {
  const el = document.getElementById("toast");
  el.textContent     = msg;
  el.className       = "toast-" + type;
  el.style.display   = "block";
  el.style.animation = "none";
  void el.offsetWidth;                    // force reflow to restart animation
  el.style.animation = "slideIn 0.3s ease";
  clearTimeout(_toastTimer);
  _toastTimer = setTimeout(() => el.style.display = "none", 3200);
}

/* ── Page routing ────────────────────────────────────────────── */
function go(name) {
  document.querySelectorAll(".page").forEach(p => p.classList.remove("active"));
  document.getElementById("page-" + name).classList.add("active");
  window.scrollTo(0, 0);
}

/* ── Navbar update ───────────────────────────────────────────── */
function updateNav() {
  const guestEl = document.getElementById("guestNav");
  const userEl  = document.getElementById("userInfo");
  const msgEl   = document.getElementById("welcomeMsg");

  if (user) {
    guestEl.style.display = "none";
    userEl.style.display  = "flex";
    msgEl.textContent     = "👋 " + user.name;
    document.getElementById("logoutBtn").onclick = doLogout;
  } else {
    guestEl.style.display = "flex";
    userEl.style.display  = "none";
  }
}

/* ── Shared helpers ──────────────────────────────────────────── */
const stars     = r => "★".repeat(Math.floor(r)) + "☆".repeat(5 - Math.floor(r));
const typeClass = t => t.toLowerCase();
const typeBadge = t => ({ PDF:"t-pdf", PPT:"t-ppt", PPTX:"t-ppt", DOC:"t-doc", DOCX:"t-doc" })[t] || "t-doc";
