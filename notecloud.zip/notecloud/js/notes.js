/* ============================================================
   js/notes.js — Notes Browsing & Interaction
   renderNotes, filterNotes, viewNote, downloadNote, rating
   ============================================================ */
"use strict";

/* ── Render notes grid (approved only) ──────────────────────── */
function renderNotes(data) {
  data = data || notes.filter(n => n.status === "approved");

  const grid  = document.getElementById("notesGrid");
  const noRes = document.getElementById("noResults");
  const count = document.getElementById("resCount");

  if (count) count.textContent = data.length + " notes";

  if (!data.length) {
    if (grid) grid.innerHTML       = "";
    if (noRes) noRes.style.display  = "block";
    return;
  }
  if (noRes) noRes.style.display = "none";

  if (grid) {
    grid.innerHTML = data.map(n => `
      <div class="note-card ${typeClass(n.type)}" onclick="viewNote('${n.id}')">
        <div class="nc-top">
          <span class="type-badge ${typeBadge(n.type)}">${n.type}</span>
          <span class="branch-pill">${n.branch}</span>
        </div>
        <div class="nc-title">${n.title}</div>
        <div class="nc-subject">📚 ${n.subject}${n.sem ? " · Sem " + n.sem : ""}</div>
        <div class="nc-desc">${n.desc}</div>
        <div class="nc-meta">
          <span>👤 ${n.uploader}</span>
          <span>📦 ${n.size}</span>
          <span>📥 ${n.dl}</span>
        </div>
        <div class="nc-stars">${stars(n.rating)}
          <span style="color:#888;font-size:12px"> ${n.rating} (${n.reviews})</span>
        </div>
        <div class="nc-actions" onclick="event.stopPropagation()">
          <button class="btn-details" onclick="viewNote('${n.id}')">👁 Details</button>
          <button class="btn-dl"      onclick="downloadNote('${n.id}')">⬇ Download</button>
        </div>
      </div>`).join("");
  }
}

/* ── Filter & Sort ───────────────────────────────────────────── */
function filterNotes() {
  const q      = (document.getElementById("searchQ").value || "").toLowerCase();
  const branch = document.getElementById("fBranch").value;
  const type   = document.getElementById("fType").value;
  const sort   = document.getElementById("fSort").value;

  let list = notes.filter(n => {
    if (n.status !== "approved") return false;
    const mQ = !q || n.title.toLowerCase().includes(q) || n.subject.toLowerCase().includes(q) || (n.tags || []).some(t => t.toLowerCase().includes(q));
    const mB = branch === "All" || n.branch === branch;
    const mT = type   === "All" || n.type   === type;
    return mQ && mB && mT;
  });

  if (sort === "popular") list.sort((a, b) => b.dl - a.dl);
  else if (sort === "rating") list.sort((a, b) => b.rating - a.rating);
  else list.sort((a, b) => new Date(b.date) - new Date(a.date));

  renderNotes(list);
}

/* ── Note detail page ────────────────────────────────────────── */
function viewNote(id) {
  const n = notes.find(x => String(x.id) === String(id));
  if (!n) return;
  selRating = 0;

  const inner = document.getElementById("detailInner");
  const tb    = typeBadge(n.type);

  inner.innerHTML = `
    <div class="detail-page">
      <span class="back-link" onclick="go('dashboard')">← Back to Notes</span>
      <div class="detail-badges">
        <span class="type-badge ${tb}">${n.type}</span>
        <span class="branch-pill">${n.branch}</span>
        ${n.sem ? `<span class="branch-pill">Semester ${n.sem}</span>` : ""}
      </div>
      <div class="detail-title">${n.title}</div>
      <p class="detail-desc-full">${n.desc}</p>
      <div class="tag-row">
        ${(n.tags || []).map(t => `<span class="tag-pill">#${t}</span>`).join("")}
      </div>
      <div class="info-box">
        <p><strong>📚 Subject:</strong> ${n.subject}</p>
        <p><strong>👤 Uploaded by:</strong> ${n.uploader}</p>
        <p><strong>📅 Upload Date:</strong> ${n.date}</p>
        <p><strong>📦 File Size:</strong> ${n.size}</p>
        <p><strong>📥 Total Downloads:</strong> ${n.dl}</p>
        <p><strong>⭐ Rating:</strong>
          <span style="color:#ffc107">${stars(n.rating)}</span>
          ${n.rating}/5 — ${n.reviews} reviews
        </p>
      </div>

      ${user ? `
      <div class="rating-area">
        <h4>⭐ Rate this Note</h4>
        <div class="star-row" id="starRow">
          <span onclick="setStar(1,'${n.id}')">★</span>
          <span onclick="setStar(2,'${n.id}')">★</span>
          <span onclick="setStar(3,'${n.id}')">★</span>
          <span onclick="setStar(4,'${n.id}')">★</span>
          <span onclick="setStar(5,'${n.id}')">★</span>
        </div>
        <button class="btn-rate" onclick="submitRating('${n.id}')">Submit Rating</button>
      </div>` : `
      <p style="color:#888;font-size:14px;margin-bottom:22px">
        🔒 <a style="color:#1a73e8;cursor:pointer;font-weight:600" onclick="go('login')">Login</a> to rate this note.
      </p>`}

      <button class="btn-big-dl" onclick="downloadNote('${n.id}')">
        ⬇ Download ${n.type} &nbsp;·&nbsp; ${n.size}
      </button>
    </div>`;

  go("detail");
}

/* ── Star rating ─────────────────────────────────────────────── */
function setStar(val) {
  selRating = val;
  document.querySelectorAll("#starRow span").forEach((s, i) =>
    s.classList.toggle("on", i < val)
  );
}

function submitRating(id) {
  if (!selRating) { toast("Please click a star first!", "err"); return; }
  const n = notes.find(x => String(x.id) === String(id));
  if (!n) return;
  const total = n.rating * n.reviews + selRating;
  const newReviews = n.reviews + 1;
  const newRating = Math.round((total / newReviews) * 10) / 10;
  
  db.collection("notes").doc(id).update({
    reviews: newReviews,
    rating: newRating
  }).then(() => {
    toast("Thanks! You rated this " + selRating + " star(s) ⭐");
    viewNote(id);
  });
}

/* ── Download ────────────────────────────────────────────────── */
function downloadNote(id) {
  if (!user) {
    toast("Please login to download notes!", "err");
    go("login");
    return;
  }
  const n = notes.find(x => String(x.id) === String(id));
  if (!n) return;
  
  // Increment DL count in Firestore
  db.collection("notes").doc(id).update({
    dl: firebase.firestore.FieldValue.increment(1)
  }).then(() => {
    // Open the local file if it exists
    if (n.localFileId) {
      const fileDataUrl = localStorage.getItem("nc_file_" + n.localFileId);
      if (fileDataUrl) {
        // Create a temporary link to download the file
        const a = document.createElement("a");
        a.href = fileDataUrl;
        a.download = n.title + "." + n.type.toLowerCase();
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        toast("Downloading \"" + n.title.slice(0, 30) + "...\" ☁️", "info");
      } else {
        toast("File content not found on this device (Demo Mode).", "info");
      }
    } else {
      toast("File link not found for this note.", "err");
    }
  });
}
