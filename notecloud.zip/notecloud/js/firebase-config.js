const firebaseConfig = {
  apiKey: "AIzaSyAK66fKfd2h6WlKTn_Xai3n3xZHWVysHMA",
  authDomain: "notecloud-a9bd8.firebaseapp.com",
  projectId: "notecloud-a9bd8",
  storageBucket: "notecloud-a9bd8.firebasestorage.app",
  messagingSenderId: "772817267006",
  appId: "1:772817267006:web:4ee3db99a5320b9ac9a46f"
};

// Initialize Firebase using compat SDK
firebase.initializeApp(firebaseConfig);

// Initialize services
const db = firebase.firestore();
const storage = firebase.storage();
const auth = firebase.auth();
