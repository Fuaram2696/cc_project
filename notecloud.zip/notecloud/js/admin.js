/* ============================================================
   js/admin.js — Admin Panel
   Login, tab switching, stats, pending approval,
   all-notes table, users table, approve / reject / delete,
   admin file upload (auto-approved)
   ============================================================ */
"use strict";

/* ── Admin credentials ───────────────────────────────────────── */
const ADMIN_CREDS = { username: "admin", password: "admin@1712" };
let isAdmin = JSON.parse(sessionStorage.getItem("nc_admin")) || false;

/* ── Admin Login ─────────────────────────────────────────────── */
function doAdminLogin() {
  const uname = document.getElementById("aUser").value.trim();
  const apass = document.getElementById("aPass").value;
  const err   = document.getElementById("adminLoginErr");
  err.style.display = "none";

  if (!uname || !apass) {
    err.textContent   = "Please enter username and password.";
    err.style.display = "block";
    return;
  }

  if (uname !== ADMIN_CREDS.username || apass !== ADMIN_CREDS.password) {
    alert("❌ Wrong admin credentials!\nUsername or password is incorrect.");
    err.textContent   = "Invalid admin credentials. Please try again.";
    err.style.display = "block";
    document.getElementById("aPass").value = "";
    return;
  }

  // Successful login
  isAdmin = true;
  sessionStorage.setItem("nc_admin", "true");

  // Log out any regular user session
  user = null;
  localStorage.removeItem("nc_user");

  // Update navbar to show Admin indicator
  document.getElementById("guestNav").style.display = "none";
  document.getElementById("userInfo").style.display = "flex";
  document.getElementById("welcomeMsg").textContent = "🛡️ Admin";
  document.getElementById("logoutBtn").onclick = adminLogout;

  adminTab("pending");
  go("admin");
  toast("Welcome, Administrator! 🛡️");
}

/* ── Admin Logout ────────────────────────────────────────────── */
function adminLogout() {
  isAdmin = false;
  sessionStorage.removeItem("nc_admin");
  updateNav();
  go("home");
  toast("Admin logged out.", "info");
}

/* ── Tab Switcher ────────────────────────────────────────────── */
function adminTab(tab) {
  // Sidebar highlight
  ["pending","allnotes","users","upload"].forEach(t => {
    const el = document.getElementById("sb-" + t);
    if (el) el.classList.toggle("active", t === tab);
  });

  // Show/hide content panels
  ["pending","allnotes","users","upload"].forEach(t => {
    const el = document.getElementById("tab-" + t);
    if (el) el.style.display = t === tab ? "block" : "none";
  });

  // Update topbar titles
  const titles = {
    pending:  ["⏳ Pending Approval",  "Review documents before they go live on the platform"],
    allnotes: ["📂 All Documents",      "Manage all uploaded documents"],
    users:    ["👥 Registered Users",   "View all students and teachers who have signed up"],
    upload:   ["📤 Upload Document",    "Upload a document as admin — auto-approved instantly"],
  };
  document.getElementById("adminPageTitle").textContent = titles[tab][0];
  document.getElementById("adminPageSub").textContent   = titles[tab][1];

  // Always refresh stats
  renderAdminStats();

  // Render active tab content
  if (tab === "pending")  renderPendingNotes();
  if (tab === "allnotes") renderAdminNotes();
  if (tab === "users")    renderAdminUsers();
}

/* ── Stat Cards ──────────────────────────────────────────────── */
function renderAdminStats() {
  const total    = notes.length;
  const pending  = notes.filter(n => n.status === "pending").length;
  const approved = notes.filter(n => n.status === "approved").length;
  const userCount= accounts.length;

  // Update red badge on sidebar
  const badge = document.getElementById("pendingBadge");
  if (badge) badge.textContent = pending;

  document.getElementById("adminStatCards").innerHTML = `
    <div class="astat-card">
      <div class="astat-icon">📂</div>
      <div>
        <div class="astat-val">${total}</div>
        <div class="astat-lbl">Total Documents</div>
      </div>
    </div>
    <div class="astat-card pending">
      <div class="astat-icon">⏳</div>
      <div>
        <div class="astat-val" style="color:#e65100">${pending}</div>
        <div class="astat-lbl">Pending Approval</div>
      </div>
    </div>
    <div class="astat-card users">
      <div class="astat-icon">✅</div>
      <div>
        <div class="astat-val" style="color:#2e7d32">${approved}</div>
        <div class="astat-lbl">Approved Live</div>
      </div>
    </div>
    <div class="astat-card rejected">
      <div class="astat-icon">👥</div>
      <div>
        <div class="astat-val" style="color:#c62828">${userCount}</div>
        <div class="astat-lbl">Registered Users</div>
      </div>
    </div>`;
}

/* ── Pending Notes Table ─────────────────────────────────────── */
function renderPendingNotes() {
  const pending = notes.filter(n => n.status === "pending");
  const body    = document.getElementById("pendingTableBody");

  if (!pending.length) {
    body.innerHTML = `<div class="admin-empty"><div class="big">✅</div><p>No documents pending approval. All clear!</p></div>`;
    return;
  }

  body.innerHTML = `
    <table class="admin-table">
      <thead>
        <tr>
          <th>Document Title</th>
          <th>Uploader</th>
          <th>Branch</th>
          <th>Type</th>
          <th>Date</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        ${pending.map(n => `
          <tr>
            <td>
              <div style="font-weight:600;color:#1a237e">${n.title}</div>
              <div style="font-size:12px;color:#888">${n.subject}</div>
            </td>
            <td>
              <div style="font-weight:500">${n.uploader}</div>
              <div style="font-size:11px;color:#888">${n.uploaderRole || "student"}</div>
            </td>
            <td><span class="branch-pill" style="font-size:11px">${n.branch}</span></td>
            <td><span class="type-badge ${typeBadge(n.type)}">${n.type}</span></td>
            <td style="color:#888;font-size:13px">${n.date}</td>
            <td>
              <div style="display:flex;gap:7px;flex-wrap:wrap">
                <button class="btn-approve" onclick="approveNote('${n.id}')">✅ Approve</button>
                <button class="btn-reject"  onclick="rejectNote('${n.id}')">❌ Reject</button>
              </div>
            </td>
          </tr>`).join("")}
      </tbody>
    </table>`;
}

/* ── All Notes Table ─────────────────────────────────────────── */
function renderAdminNotes() {
  const q    = (document.getElementById("adminSearch")?.value || "").toLowerCase();
  const list = notes.filter(n =>
    !q || n.title.toLowerCase().includes(q) || n.uploader.toLowerCase().includes(q)
  );
  const body = document.getElementById("allNotesTableBody");

  if (!list.length) {
    body.innerHTML = `<div class="admin-empty"><div class="big">📭</div><p>No documents found.</p></div>`;
    return;
  }

  const statusBadge = s => {
    if (s === "approved") return `<span class="status-badge status-approved">✅ Approved</span>`;
    if (s === "rejected") return `<span class="status-badge status-rejected">❌ Rejected</span>`;
    return `<span class="status-badge status-pending">⏳ Pending</span>`;
  };

  body.innerHTML = `
    <table class="admin-table">
      <thead>
        <tr>
          <th>Title</th>
          <th>Uploader</th>
          <th>Branch / Type</th>
          <th>Downloads</th>
          <th>Status</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        ${list.map(n => `
          <tr>
            <td>
              <div style="font-weight:600;color:#1a237e;max-width:200px">${n.title}</div>
              <div style="font-size:12px;color:#888">${n.subject} · ${n.date}</div>
            </td>
            <td>
              <div style="font-weight:500">${n.uploader}</div>
              <div style="font-size:11px;color:#888">${n.uploaderRole || "student"}</div>
            </td>
            <td>
              <span class="branch-pill" style="font-size:11px">${n.branch}</span>
              <span class="type-badge ${typeBadge(n.type)}" style="margin-left:5px">${n.type}</span>
            </td>
            <td style="font-weight:600;color:#1a73e8">📥 ${n.dl}</td>
            <td>${statusBadge(n.status)}</td>
            <td>
              <div style="display:flex;gap:6px;flex-wrap:wrap">
                ${n.status === "pending"  ? `<button class="btn-approve" onclick="approveNote('${n.id}');renderAdminNotes()">✅ Approve</button>` : ""}
                ${n.status === "pending"  ? `<button class="btn-reject"  onclick="rejectNote('${n.id}');renderAdminNotes()">❌ Reject</button>`  : ""}
                ${n.status === "rejected" ? `<button class="btn-approve" onclick="approveNote('${n.id}');renderAdminNotes()" style="font-size:11px">♻️ Re-approve</button>` : ""}
                <button class="btn-delete" onclick="adminDeleteNote('${n.id}')">🗑️ Delete</button>
              </div>
            </td>
          </tr>`).join("")}
      </tbody>
    </table>`;
}

/* ── Users Table ─────────────────────────────────────────────── */
function renderAdminUsers() {
  const body = document.getElementById("usersTableBody");
  const lbl  = document.getElementById("userCountLabel");
  if (lbl) lbl.textContent = accounts.length + " total users";

  if (!accounts.length) {
    body.innerHTML = `<div class="admin-empty"><div class="big">👥</div><p>No users registered yet.</p></div>`;
    return;
  }

  body.innerHTML = `
    <table class="admin-table">
      <thead>
        <tr>
          <th>#</th>
          <th>Full Name</th>
          <th>Email Address</th>
          <th>Role</th>
          <th>Branch</th>
          <th>Documents Uploaded</th>
        </tr>
      </thead>
      <tbody>
        ${accounts.map((a, i) => {
          const userNotes = notes.filter(n => n.uploaderEmail === a.email || n.uploader === a.name);
          return `
          <tr>
            <td style="color:#888;font-size:13px">${i + 1}</td>
            <td style="font-weight:600;color:#1a237e">${a.name}</td>
            <td style="color:#555">${a.email}</td>
            <td><span class="role-${a.role}">${a.role === "teacher" ? "👨‍🏫 Teacher" : "🎓 Student"}</span></td>
            <td><span class="branch-pill" style="font-size:11px">${a.branch || "—"}</span></td>
            <td>
              <span style="font-weight:700;color:#1a73e8">${userNotes.length}</span>
              <span style="color:#888;font-size:12px"> (${userNotes.filter(n => n.status === "pending").length} pending)</span>
            </td>
          </tr>`;
        }).join("")}
      </tbody>
    </table>`;
}

/* ── Approve ─────────────────────────────────────────────────── */
function approveNote(noteId) {
  db.collection("notes").doc(String(noteId)).update({ status: "approved" }).then(() => {
    toast("✅ Document approved and now live!");
  }).catch(e => console.error(e));
}

/* ── Reject ──────────────────────────────────────────────────── */
function rejectNote(noteId) {
  const ok = window.confirm("Reject document?\nIt will NOT be shown on the platform.");
  if (!ok) return;
  db.collection("notes").doc(String(noteId)).update({ status: "rejected" }).then(() => {
    toast("❌ Document rejected.", "err");
  }).catch(e => console.error(e));
}

/* ── Delete ──────────────────────────────────────────────────── */
function adminDeleteNote(noteId) {
  const ok    = window.confirm("Delete document?\n\nThis cannot be undone.");
  if (!ok) return;

  db.collection("notes").doc(String(noteId)).delete().then(() => {
    toast("🗑️ Document deleted.", "err");
  }).catch(e => console.error(e));
}

/* ── Admin file helpers ──────────────────────────────────────── */
function adminFileSelected(input) {
  const f = input.files[0];
  if (!f) return;
  document.getElementById("auDzIcon").textContent = "📄";
  document.getElementById("auDzTxt").textContent  = "✅ Selected: " + f.name;
  const titleEl = document.getElementById("auTitle");
  if (!titleEl.value) titleEl.value = f.name.replace(/\.[^.]+$/, "").replace(/[-_]/g, " ");
  const ext    = f.name.split(".").pop().toUpperCase();
  const typeEl = document.getElementById("auType");
  if      (["PPT","PPTX"].includes(ext)) typeEl.value = "PPT";
  else if (["DOC","DOCX"].includes(ext)) typeEl.value = "DOC";
  else                                    typeEl.value = "PDF";
}

function adminFileDrop(e) {
  e.preventDefault();
  document.getElementById("auDropzone").style.background = "#f7fbff";
  const dt = e.dataTransfer;
  if (dt.files && dt.files[0]) {
    document.getElementById("auFileInput").files = dt.files;
    adminFileSelected({ files: dt.files });
  }
}

/* ── Admin Upload (auto-approved) ────────────────────────────── */
function adminUpload() {
  const title   = document.getElementById("auTitle").value.trim();
  const subject = document.getElementById("auSubject").value.trim();
  const branch  = document.getElementById("auBranch").value;
  const type    = document.getElementById("auType").value;
  const sem     = document.getElementById("auSem").value;
  const tags    = document.getElementById("auTags").value;
  const desc    = document.getElementById("auDesc").value.trim();
  const file    = document.getElementById("auFileInput").files[0];

  if (!title || !subject) { toast("Title and subject are required!", "err"); return; }
  if (!file)              { toast("Please select a file to upload!", "err"); return; }

  const sizeMB = (file.size / (1024 * 1024)).toFixed(1) + " MB";

  const btn    = document.getElementById("auSubmitBtn");
  const progEl = document.getElementById("auProgArea");
  const fill   = document.getElementById("auProgFill");
  const txt    = document.getElementById("auProgTxt");

  btn.disabled    = true;
  btn.textContent = "Uploading...";
  progEl.style.display = "block";
  fill.style.width     = "0%";

  let pct = 0;
  const iv = setInterval(() => {
    pct += Math.random() * 15 + 8;
    if (pct >= 100) {
      clearInterval(iv);
      fill.style.width = "100%";
      txt.textContent  = "✅ Upload complete!";

      const reader = new FileReader();
      reader.onload = function(e) {
        const fileDataUrl = e.target.result;
        const noteId = Date.now().toString();

        try {
          localStorage.setItem("nc_file_" + noteId, fileDataUrl);
        } catch(err) {
          console.warn("File too large for local storage");
        }

        const newNote = {
          title, subject, branch, type,
          sem:           sem || null,
          uploader:      "Admin",
          uploaderEmail: "admin@notecloud.com",
          uploaderRole:  "admin",
          desc:          desc || "Document uploaded by Admin.",
          tags:          tags ? tags.split(",").map(t => t.trim()).filter(Boolean) : [],
          size:          sizeMB,
          dl: 0, rating: 0, reviews: 0,
          date:   new Date().toISOString().slice(0, 10),
          status: "approved",
          localFileId: noteId
        };

        db.collection("notes").doc(noteId).set(newNote).then(() => {
          setTimeout(() => {
            // Reset form
            ["auTitle","auSubject","auTags","auDesc"].forEach(id => document.getElementById(id).value = "");
            document.getElementById("auSem").value      = "";
            document.getElementById("auFileInput").value = "";
            document.getElementById("auDzIcon").textContent = "☁️";
            document.getElementById("auDzTxt").innerHTML    = "Click to select file or <span style='color:#1a73e8;font-weight:600'>drag & drop</span>";
            progEl.style.display = "none";
            fill.style.width     = "0%";
            btn.disabled         = false;
            btn.textContent      = "📤 Upload & Auto-Approve";

            toast("✅ \"" + title + "\" uploaded and live on the platform!");
            adminTab("allnotes");
          }, 600);
        });
      };
      reader.readAsDataURL(file);
    } else {
      fill.style.width = pct + "%";
      txt.textContent  = "Uploading to cloud... " + Math.floor(pct) + "%";
    }
  }, 150);
}
