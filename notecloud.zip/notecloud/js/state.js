/* ============================================================
   js/state.js — Shared App State & Default Data
   Loaded FIRST by index.html (all other JS files depend on this)
   ============================================================ */
"use strict";

/* ── App-wide state ──────────────────────────────────────────── */
let user      = JSON.parse(localStorage.getItem("nc_user"))     || null;
let notes     = [];
let accounts  = [];
let selRating = 0;

/* ── Listen to Firestore Notes ───────────────────────────────── */
if (typeof db !== "undefined") {
  db.collection("notes").orderBy("date", "desc").onSnapshot((snapshot) => {
    notes = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    
    // Re-render UI when notes update
    if (typeof renderNotes === 'function') renderNotes();
    if (typeof renderPendingNotes === 'function' && typeof isAdmin !== 'undefined' && isAdmin) {
      renderPendingNotes();
      renderAdminNotes();
      renderAdminStats();
    }
  });

  /* ── Listen to Firestore Users ───────────────────────────────── */
  db.collection("users").onSnapshot((snapshot) => {
    accounts = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    if (typeof renderAdminUsers === 'function' && typeof isAdmin !== 'undefined' && isAdmin) {
      renderAdminUsers();
      renderAdminStats();
    }
  });
}

/* ── Persist helpers ─────────────────────────────────────────── */
function saveData() {
  localStorage.setItem("nc_user",  JSON.stringify(user));
}

function saveAccounts() {
  // Accounts are now saved directly to Firestore in auth.js
}
