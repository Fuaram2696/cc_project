/* ============================================================
   js/upload.js — Upload Modal (Students & Teachers)
   Uploaded notes go to "pending" status for admin review
   ============================================================ */
"use strict";

/* ── Open / Close ────────────────────────────────────────────── */
function openUpload() {
  if (!user) { toast("Please login first!", "err"); return; }
  document.getElementById("uploadOverlay").classList.add("open");
}

function closeUpload() {
  document.getElementById("uploadOverlay").classList.remove("open");
  resetUpload();
}

/* ── File selected ───────────────────────────────────────────── */
function onFileSelected(input) {
  const f = input.files[0];
  if (!f) return;
  document.getElementById("dzIco").textContent = "📄";
  document.getElementById("dzTxt").textContent  = "Selected: " + f.name;
  // Auto-fill title from filename
  const titleEl = document.getElementById("uTitle");
  if (!titleEl.value) {
    titleEl.value = f.name.replace(/\.[^.]+$/, "").replace(/[-_]/g, " ");
  }
}

/* ── Submit upload ───────────────────────────────────────────── */
function submitUpload() {
  const title   = document.getElementById("uTitle").value.trim();
  const subject = document.getElementById("uSubject").value.trim();
  const branch  = document.getElementById("uBranch").value;
  const sem     = document.getElementById("uSem").value;
  const tags    = document.getElementById("uTags").value;
  const desc    = document.getElementById("uDesc").value.trim();
  const file    = document.getElementById("fileInput").files[0];

  if (!title || !subject) {
    toast("Title and subject are required!", "err");
    return;
  }
  
  if (!file) {
    toast("Please select a file to upload!", "err");
    return;
  }

  const ext  = file.name.split(".").pop().toUpperCase();
  const type = ["PPT","PPTX"].includes(ext) ? "PPT" : (["DOC","DOCX"].includes(ext) ? "DOC" : "PDF");
  const size = (file.size / (1024 * 1024)).toFixed(1) + " MB";

  // We can't use Firebase Storage without a credit card, so we'll simulate the upload 
  // and store the file locally in the browser, while the DATA goes to the cloud!

  const btn  = document.getElementById("upSubmitBtn");
  const area = document.getElementById("progArea");
  const fill = document.getElementById("progFill");
  const txt  = document.getElementById("progTxt");

  btn.disabled    = true;
  btn.textContent = "Uploading...";
  area.style.display = "block";
  fill.style.width = "0%";
  
  let pct = 0;
  const iv = setInterval(() => {
    pct += Math.random() * 15 + 8;
    if (pct >= 100) {
      clearInterval(iv);
      fill.style.width = "100%";
      txt.textContent  = "✅ Upload complete!";

      // Read file as Base64 to store locally
      const reader = new FileReader();
      reader.onload = function(e) {
        const fileDataUrl = e.target.result;
        const noteId = Date.now().toString();

        // Store the actual file in localStorage so it can be downloaded later on this PC
        try {
          localStorage.setItem("nc_file_" + noteId, fileDataUrl);
        } catch(err) {
          console.warn("File too large for local storage, skipping file content save.");
        }

        // Save note metadata to the REAL CLOUD (Firestore)
        const newNote = {
          title, subject, branch, type,
          sem:           sem || null,
          uploader:      user.name,
          uploaderEmail: user.email,
          uploaderRole:  user.role,
          desc:          desc || "Notes uploaded by " + user.name,
          tags:          tags ? tags.split(",").map(t => t.trim()).filter(Boolean) : [],
          size,
          dl: 0, rating: 0, reviews: 0,
          date:   new Date().toISOString().slice(0, 10),
          status: "pending",
          localFileId: noteId // Reference to the local file
        };

        db.collection("notes").doc(noteId).set(newNote).then(() => {
          setTimeout(() => {
            closeUpload();
            toast("\"" + title + "\" submitted! ⏳ Waiting for admin approval.", "info");
          }, 600);
        }).catch(err => {
          console.error(err);
          toast("Failed to save note info.", "err");
          resetUpload();
        });
      };
      reader.readAsDataURL(file);

    } else {
      fill.style.width = pct + "%";
      txt.textContent  = "Uploading to cloud... " + Math.floor(pct) + "%";
    }
  }, 140);
}

/* ── Reset form ──────────────────────────────────────────────── */
function resetUpload() {
  ["uTitle","uSubject","uTags","uDesc"].forEach(id => document.getElementById(id).value = "");
  document.getElementById("uSem").value      = "";
  document.getElementById("fileInput").value = "";
  document.getElementById("dzIco").textContent = "☁️";
  document.getElementById("dzTxt").innerHTML   = "Click to select or <span>drag & drop</span>";
  document.getElementById("progArea").style.display = "none";
  document.getElementById("progFill").style.width   = "0%";
  const btn = document.getElementById("upSubmitBtn");
  btn.disabled    = false;
  btn.textContent = "📤 Upload to Cloud";
}
